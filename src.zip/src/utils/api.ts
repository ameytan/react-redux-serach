import { get as getVerb } from "@amiga-fwk-web/api-utils/verbs";
import { decorate } from "@amiga-fwk-web/api-utils/decorators";
import type { HttpVerbDecorator } from "@amiga-fwk-web/api-utils/decorators";
import { config } from "@amiga-fwk-web/global";
import { withExtranetAuth } from "@amiga-fwk-web/auth-extranet/decorators";
import { get, post, put, del } from "@amiga-fwk-web/api-utils/verbs";
import { withJanusAuth } from "@amiga-fwk-web/auth-janus/decorators";

const setAppBackend: HttpVerbDecorator =
  (fn) =>
  (endpoint, options = {}) =>
    fn(`${config.getEndpoint("main")}${endpoint}`, { ...options });

const [getApp, postApp, putApp, delApp] = decorate(withJanusAuth(), setAppBackend, [get, post, put, del]);
export default {
  getApp,
  postApp,
  putApp,
  delApp,
};
