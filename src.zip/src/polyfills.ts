/* istanbul ignore file */

import "@amiga-fwk-web/polyfills";

// Add here other prolyfills if you need them
