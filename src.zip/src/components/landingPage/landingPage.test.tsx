import React from "react";
import LandingPage from "./landingPage";
import { shallow } from "@amiga-fwk-web/tools/testing";

jest.mock("../../utils/api");
jest.mock("@amiga-fwk-web/components-action/button");
jest.mock("@amiga-fwk-web/icons/actions/icon-add");
jest.mock("./landingPage.scss");
jest.mock("@amiga-fwk-web/components-routing/use-history");

describe("<LandingPage>", () => {
  it("should render component", () => {
    const wrapper = shallow(<LandingPage />);
    const component = wrapper.find(".landingPage");
    expect(component).toHaveLength(1);
  });
});
