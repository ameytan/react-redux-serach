import React, { useState, useEffect } from "react";
import Page from "../../layout/page";
import Text from "@amiga-fwk-web/components-content/text";
import Searcher from "@amiga-fwk-web/x-searcher/searcher";
import ActionButton from "@amiga-fwk-web/components-action/action-button";
import IconCloseLarge from "@amiga-fwk-web/icons/actions/icon-close-large";
import Image from "@amiga-fwk-web/components-content/image";
import "./landingPage.scss";
import useHistory from "@amiga-fwk-web/components-routing/use-history";
import api from "../../utils/api";
// eslint-disable-next-line

//const data: any = require("@/assets/api/local.json");

const LandingPage = () => {
  const [searcherValue, setSearcherValue] = useState("");
  const [suggestionValues, setSuggestionValues] = useState<string[]>([]);
  const [resultArray, setResultArray] = useState<string[]>([]);
  const [dataArray, setDataArray] = useState<string[]>([]);
  const history = useHistory();

  useEffect(() => {
    api
      .getApp("/api/v1/stores")
      .then((response: any) => response.json())
      .then((result: any) => {
        console.log(result.data.data);
        setDataArray(result.data.data);
      })
      .catch((err: any) => {
        console.log(err);
      });
  }, []);

  useEffect(() => {
    let temp: any = dataArray.filter((x: any) => x[0].toString().indexOf(searcherValue) > -1);
    setResultArray(temp);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searcherValue]);

  useEffect(() => {
    var new_temp = resultArray.map((x: any) => x[0].toString());
    setSuggestionValues(new_temp);
  }, [resultArray]);

  return (
    <Page>
      <div className="landingPage" data-testid="landingPage">
        <Image src={require("/assets/img/home.jpg")} className="mainImg" />
        <Text kind="h5" className="title">
          BIENVENIDO A INSTALL CONTROL
        </Text>
        <Text className="subTitle">Busca o introduce el código de la tienda</Text>
        <Searcher
          suggestionItems={suggestionValues}
          value={searcherValue}
          onChange={setSearcherValue}
          className={"searchbar"}
          onClear={(value: any) => {
            console.log("clear");
          }}
          onSearch={(value: any) => {
            setSearcherValue(value);
            searcherValue &&
              history.push({
                pathname: "/result-page",
                state: resultArray,
              });
          }}
          label={"BUSCAR TIENDA"}
          actionButtons={[
            <ActionButton
              key="first"
              iconStart={<IconCloseLarge />}
              onClick={(value: any) => {
                console.log("clear 2");
              }}
            />,
          ]}
        />
      </div>
    </Page>
  );
};

export default LandingPage;
