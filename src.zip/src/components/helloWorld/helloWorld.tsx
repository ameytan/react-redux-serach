import React, { useState, useEffect } from "react";
import Page from "../../layout/page";
import Text from "@amiga-fwk-web/components-content/text";

const HelloWorld = () => {
  return (
    <Page>
      <Text kind="h1" testId="helloWorld">
        Hello World!
      </Text>
    </Page>
  );
};

export default HelloWorld;
