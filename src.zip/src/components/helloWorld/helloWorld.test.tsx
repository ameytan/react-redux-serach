import React from "react";
import { render, waitFor, screen } from "@testing-library/react";
import { AppWrapper } from "#/test.utils";
import HelloWorld from "./helloWorld";

jest.mock(
  "react-virtualized-auto-sizer",
  () =>
    ({ children }: { children: (size: { width: number; height: number }) => React.ReactNode }) => {
      return children({ width: 1280, height: 1024 });
    },
);

Object.defineProperty(window, "matchMedia", {
  value: () => {
    return {
      matches: false,
      addListener: jest.fn(),
      removeListener: jest.fn(),
    };
  },
});

describe("ProductsPage component", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });
  test("Hello world visible", async () => {
    render(
      <AppWrapper>
        <HelloWorld />
      </AppWrapper>,
    );
    expect(screen.getByTestId("helloWorld")).toBeInTheDocument();
  });
});
