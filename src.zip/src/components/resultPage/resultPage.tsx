import React, { useState, useEffect } from "react";
import Page from "../../layout/page";
import Searcher from "@amiga-fwk-web/x-searcher/searcher";
import ActionButton from "@amiga-fwk-web/components-action/action-button";
import IconCloseLarge from "@amiga-fwk-web/icons/actions/icon-close-large";
import "./resultPage.scss";
import useHistory from "@amiga-fwk-web/components-routing/use-history";
import api from "../../utils/api";

const ResultPage = () => {
  const [searcherValue, setSearcherValue] = useState("");
  const [suggestionValues, setSuggestionValues] = useState<string[]>([]);
  const [resultArray, setResultArray] = useState<string[]>([]);
  // eslint-disable-next-line
  const data: any = require("@/assets/api/local.json");
  const history = useHistory();
  const [searchResultArray, setSearchResultArray] = useState<string[]>([]);
  let prevData: any = history?.location?.state || 0;
  const [dataArray, setDataArray] = useState<string[]>([]);

  useEffect(() => {
    api
      .getApp("/api/v1/stores")
      .then((response: any) => response.json())
      .then((result: any) => {
        console.log(result.data.data);
        setDataArray(result.data.data);
      })
      .catch((err: any) => {
        console.log(err);
      });
  }, []);

  useEffect(() => {
    setSearchResultArray([...prevData]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    let temp: any = dataArray.filter((x: any) => x[0]?.toString()?.indexOf(searcherValue) > -1);
    setResultArray(temp);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searcherValue]);

  useEffect(() => {
    var new_temp = resultArray.map((x: any) => x[0]?.toString());
    setSuggestionValues(new_temp);
  }, [resultArray]);

  return (
    <Page>
      <div className="resultPage" data-testid="resultPage">
        <div className="container">
          <Searcher
            suggestionItems={suggestionValues}
            value={searcherValue}
            onChange={setSearcherValue}
            className={"searchbar"}
            onClear={(value: any) => {
              //console.log("clear");
            }}
            onSearch={(value: any) => {
              setSearcherValue(value);
              setSearchResultArray(resultArray);
            }}
            label={"BUSCAR TIENDA"}
            actionButtons={[
              <ActionButton
                key="first"
                iconStart={<IconCloseLarge />}
                onClick={(value: any) => {
                  //console.log("clear 2");
                }}
              />,
            ]}
          />
          <div className="resultBox">
            {searchResultArray.map((x: any) => (
              <div className="row" key={x[0]}>
                <div className="storeLogo">ZARA</div>
                <div className="middle_col">
                  <div className="storeTitle">{x[1]}</div>
                  <div className="storeId">{x[0]}</div>
                </div>
                <a className="arrow" href="#">
                  {">"}
                </a>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Page>
  );
};

export default ResultPage;
