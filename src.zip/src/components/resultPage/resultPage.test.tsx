import React from "react";
import ResultPage from "./resultPage";
import { shallow } from "@amiga-fwk-web/tools/testing";

jest.mock("../../utils/api");
jest.mock("@amiga-fwk-web/components-action/button");
jest.mock("@amiga-fwk-web/icons/actions/icon-add");
jest.mock("./resultPage.scss");
jest.mock("@amiga-fwk-web/components-routing/use-history");

describe("<ResultPage>", () => {
  it("should render component", () => {
    const wrapper = shallow(<ResultPage />);
    const component = wrapper.find(".resultPage");
    expect(component).toHaveLength(1);
  });
});
