/* istanbul ignore file */

import React from "react";
import ReactDOM from "react-dom";
import Auth from "@amiga-fwk-web/auth/auth";
import AuthSwitch from "@amiga-fwk-web/auth/auth-switch";
import ComponentEventsProvider from "@amiga-fwk-web/components-utils/component-events-provider";
import ConfigProvider from "@amiga-fwk-web/config/config-provider";
import IntlProvider from "@amiga-fwk-web/components-intl/intl-provider";
import JanusProvider from "@amiga-fwk-web/auth-janus/janus-provider";
import Layout from "@/layout";
import LogProvider from "@amiga-fwk-web/logging/log-provider";
import NotificationsProvider from "@amiga-fwk-web/components-feedback/notifications-provider";
import Router from "@amiga-fwk-web/components-routing/router";
import consoleTransport from "@amiga-fwk-web/logging/console-transport";
import logger from "@amiga-fwk-web/logging/logger";
import { locales, messages } from "./modules";
import Login from "@amiga-fwk-web/components-login/login";
import "./assets/styles/custom.scss";
import HashRouter from "@amiga-fwk-web/components-routing/router";
import Route from "@amiga-fwk-web/components-routing/route";
import Switch from "@amiga-fwk-web/components-routing/switch";
import HelloWorld from "@/components/helloWorld/helloWorld";
import LandingPage from "@/components/landingPage/landingPage";
import ResultPage from "@/components/resultPage/resultPage";

import { defaultErrorHandler } from "@amiga-fwk-web/errors";

export const backgroundImage =
  "https://comercial.central.inditex.grp/amgfilemw-comercial/web/public/apps-home-data/zar/home-s2880.jpg";

const createLogger = () =>
  logger({
    transports: [consoleTransport()],
  });
const Application = () => (
  <ConfigProvider>
    {() => (
      <LogProvider logger={createLogger()}>
        <ComponentEventsProvider>
          <NotificationsProvider>
            <Auth provider={<JanusProvider />}>
              <IntlProvider>
                <AuthSwitch
                  layout={
                    <Login
                      backgroundUrl={backgroundImage}
                      title="BUSCADOR"
                      subtitle="ACCESS YOUR USER ACCOUNT"
                      version="V.1.0"
                    />
                  }
                >
                  <Router>
                    <HashRouter>
                      <Layout>
                        <Switch>
                          <Route exact path="/hello-world">
                            <HelloWorld />
                          </Route>
                          <Route exact path="/">
                            <LandingPage />
                          </Route>
                          <Route exact path="/result-page">
                            <ResultPage />
                          </Route>
                        </Switch>
                      </Layout>
                    </HashRouter>
                  </Router>
                </AuthSwitch>
              </IntlProvider>
            </Auth>
          </NotificationsProvider>
        </ComponentEventsProvider>
      </LogProvider>
    )}
  </ConfigProvider>
);

window.addEventListener("error", defaultErrorHandler);
window.addEventListener("unhandledrejection", defaultErrorHandler);

ReactDOM.render(<Application />, document.getElementById("app"));
