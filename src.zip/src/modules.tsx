import messages from "config/locales";
export { messages };

export const locales = Object.keys(messages);
