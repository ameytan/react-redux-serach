/* istanbul ignore file */

import React from "react";
import FormattedMessage from "@amiga-fwk-web/components-intl/formatted-message";
import DefaultApplicationLayout from "@amiga-fwk-web/components-application/default-application-layout";
import type { DefaultApplicationLayoutProps } from "@amiga-fwk-web/components-application/default-application-layout";
import "./layout.scss";
import ZaraLogo from "@amiga-fwk-web/x-logos/logos/zara";

type Props = {
  children?: React.ReactNode;
  menuEntries?: DefaultApplicationLayoutProps["menuEntries"];
};

const Layout: React.FC<Props> = ({ menuEntries, children }) => (
  <DefaultApplicationLayout
    applicationName={<span>BUSCADOR</span>}
    logo={<ZaraLogo />}
    menuButton={false}
    color={"light"}
  >
    {children}
  </DefaultApplicationLayout>
);

export default Layout;
