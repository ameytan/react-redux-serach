export interface IUseCases {
  name: string;
}
