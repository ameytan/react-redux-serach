export const fetchData = () => {
    return (dispatch:any) => {
      fetch('http://localhost:3000/products')
        .then((response) => response.json())
        .then((data) =>
          dispatch({
            type: 'FETCH_DATA_SUCCESS',
            payload: data,
          })
        )
        .catch((error) =>
          dispatch({
            type: 'FETCH_DATA_FAILURE',
            payload: error,
          })
        );
    };
  };
  