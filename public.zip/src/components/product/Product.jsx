import React, { Component } from 'react';
import ProductItem from "./product-item/ProductItem";
import ProductSearchBar from "./product-search-bar/ProductSearchBar";

class Product extends Component {
  constructor(props) {
    super(props);

    this.state = {
      searchQuery: '',
      filteredData: [],
    };
  }

  componentDidUpdate(prevProps) {
    if (prevProps.data !== this.props.data) {
      this.setState({
        filteredData: this.props.data,
      });
    }
  }

  handleSearchInputChange = (event) => {
    const searchQuery = event.target.value;
    const { data } = this.props;

    const filteredData = data.filter((item) =>
      item.name['de_de'].toLowerCase().includes(searchQuery.toLowerCase())
    );

    this.setState({
      searchQuery,
      filteredData,
    });
  };

    render() {
      const { searchQuery, filteredData } = this.state;

        return (
          <div>
              <div className="container">
                  <div className="header">
                      <h4>Abelssoft Products</h4>
                      <div className='px-64 pb-8'>
                          <ProductSearchBar searchQuery={searchQuery}
          handleSearchInputChange={this.handleSearchInputChange} />
                      </div>
                  </div>

                  <div className="products">
                      {filteredData.map((product) => (
                        <ProductItem data={product} key={product.id} />
                      ))}
                  </div>
              </div>
          </div>
        );
    }
}

export default Product;