import React, {Component} from 'react';

class ProductSearchBar extends Component {
    render() {
        const { handleSearchInputChange } = this.props;

        return (
            <div className="input-group">
                <input type="text" className="form-control" placeholder="Search Term" onChange={handleSearchInputChange}/>
                <div className="input-group-append">
                    <button className="btn btn-danger" type="button">Search</button>
                </div>
            </div>
        );
    }
}

export default ProductSearchBar;
