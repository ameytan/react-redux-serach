import React, {Component} from 'react';
import {ProductData} from "../../../models/product.entity";

interface ProductItemProps {
    data: ProductData;
}

class ProductItem extends Component<ProductItemProps> {
    render() {
        return (
            <div className="product">
                <div key={this.props.data.id}>
                    <div className="image">
                        <img
                            src={this.props.data.boxshotUrl}
                            alt={this.props.data.name["de_de"]}/>
                    </div>
                    <div className="namePrice">
                        <h4>{this.props.data.name["de_de"]}</h4>
                    </div>
                    <div>
                        <p>{this.props.data.description["de_de"]}</p>
                    </div>
                    <div>
                        <p>{this.props.data.price.CHF.toString().replace('.', ',')}</p>
                    </div>
                </div>

            </div>
        );
    }
}

export default ProductItem;
