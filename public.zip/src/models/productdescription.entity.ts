export interface ProductDescription {
    'de_de': string;
    'en_us': string;
}
