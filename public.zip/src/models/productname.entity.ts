export interface ProductName {
    'de_de': string;
    'en_us': string;
}
