import { ProductDescription } from "./productdescription.entity";
import { ProductName } from "./productname.entity";
import { ProductPrice } from "./productprice.entity";

export interface ProductData {
    id: number;
    name:  ProductName;
    description:  ProductDescription;
    price:  ProductPrice;
    boxshotUrl: string;
    active: boolean;
}
