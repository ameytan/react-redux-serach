export interface ProductPrice {
    'EUR': number;
    'USD': number;
    'CHF': number;
}
