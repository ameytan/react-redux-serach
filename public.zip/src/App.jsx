import React from 'react';
import './App.css';
import Product from "./components/product/Product";
import { connect } from 'react-redux';
import { fetchData } from './redux/actions/products';

class App extends React.Component {

  componentDidMount() {
    this.props.fetchData();
  }

  

  render() {
    return (
      <div>
        <nav className="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
          <div className="container-fluid">
            <span className="navbar-brand">
              <img src="https://ascora.de/wp-content/uploads/2021/11/ascora-logo.b687c5a.svg" alt="react logo"
                height="40" className="d-inline-block align-text-top" />
            </span>
            <div className="d-none d-md-block">
              <h1 className="h3 fw-bold ms-5">Job Interview Challenge</h1>
            </div>
          </div>
        </nav>
        <main className="mx-auto py-6 sm:px-6 lg:px-8">
          <div className="px-4 py-6 sm:px-0">
            <Product data={this.props.data} />
          </div>
        </main>
      </div>
    )
  }
}

const mapStateToProps = (state) => ({
  data: state.data,
});

const mapDispatchToProps = {
  fetchData,
};

export default connect(mapStateToProps, mapDispatchToProps)(App);